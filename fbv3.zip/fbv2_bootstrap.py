import os
import sys
import getpass
import requests
import hashlib

from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad, pad

# ================= CONFIG =================
SERVER_URL = "http://217.154.114.227:11017/activate"
ENC_FILE = "fbv2.enc"
CACHE_FILE = "cache.bin"
# =========================================


# -------- DEVICE ID --------
def get_device_id():
    base = (
        os.getenv("COMPUTERNAME")
        or os.getenv("HOSTNAME")
        or "unknown-device"
    )
    return hashlib.sha256(base.encode()).hexdigest()


# -------- DECRYPT PAYLOAD --------
def decrypt_blob(blob: bytes, key: bytes) -> bytes:
    iv = blob[:16]
    data = blob[16:]
    cipher = AES.new(key, AES.MODE_CBC, iv)
    return unpad(cipher.decrypt(data), AES.block_size)


# -------- CACHE ACTIVATION KEY (ENCRYPTED) --------
def derive_cache_key():
    device = get_device_id().encode()
    return hashlib.sha256(device).digest()


def save_cached_activation_key(act_key: str):
    key = derive_cache_key()
    cipher = AES.new(key, AES.MODE_CBC)
    enc = cipher.encrypt(pad(act_key.encode(), AES.block_size))

    with open(CACHE_FILE, "wb") as f:
        f.write(cipher.iv + enc)


def load_cached_activation_key():
    if not os.path.exists(CACHE_FILE):
        return None

    try:
        key = derive_cache_key()
        with open(CACHE_FILE, "rb") as f:
            data = f.read()

        iv = data[:16]
        enc = data[16:]
        cipher = AES.new(key, AES.MODE_CBC, iv)
        return unpad(cipher.decrypt(enc), AES.block_size).decode()
    except:
        return None


# -------- CALL SERVER --------
def call_activation_server(act_key: str):
    r = requests.post(
        SERVER_URL,
        json={
            "key": act_key,
            "device_id": get_device_id()
        },
        timeout=10
    )
    return r.json()


# ================= MAIN =================
def main():
    with open(ENC_FILE, "rb") as f:
        blob = f.read()

    activation_key = load_cached_activation_key()
    plaintext = None

    for attempt in range(3):
        if not activation_key:
            activation_key = getpass.getpass("Activation key: ").strip()

        print("Verifying activation key...")

        resp = call_activation_server(activation_key)

        if not resp or not resp.get("ok"):
            print("Activation failed:", resp.get("error"))
            activation_key = None
            continue

        try:
            payload_hex = resp["key"]
            username = resp.get("username", "unknown")
            payload_key = bytes.fromhex(payload_hex)

            plaintext = decrypt_blob(blob, payload_key)

            save_cached_activation_key(activation_key)

            print(f"Activated for user: {username}")
            break

        except Exception:
            print("Decryption failed")
            activation_key = None

    if plaintext is None:
        print("Activation required")
        sys.exit(1)

    exec(plaintext, globals(), globals())


if __name__ == "__main__":
    main()
